package com.example.blood_donationapp.base;


public interface BasePresenter {
  void onCreate();

  void onStart();

  void onStop();

  void onDestroy();
}
