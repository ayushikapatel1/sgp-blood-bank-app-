package com.example.blood_donationapp.ui.about;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.blood_donationapp.R;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
