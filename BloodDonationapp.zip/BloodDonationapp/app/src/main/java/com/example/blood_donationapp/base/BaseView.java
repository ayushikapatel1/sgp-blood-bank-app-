package com.example.blood_donationapp.base;

import androidx.annotation.StringRes;

public interface BaseView {


    void generalResponse(@StringRes int responseId);
}
