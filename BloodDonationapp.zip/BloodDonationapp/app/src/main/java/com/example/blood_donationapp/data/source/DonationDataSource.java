package com.example.blood_donationapp.data.source;

import com.example.blood_donationapp.data.model.ReceiverDonorRequestType;
import com.example.blood_donationapp.data.model.User;

public interface DonationDataSource {
  void saveNewUser(String userId, User user);

  void saveReceiverDetails(String userId, ReceiverDonorRequestType receiverDonorRequestType);

  void saveDonorDetails(String userId, ReceiverDonorRequestType receiverDonorRequestType);
}
