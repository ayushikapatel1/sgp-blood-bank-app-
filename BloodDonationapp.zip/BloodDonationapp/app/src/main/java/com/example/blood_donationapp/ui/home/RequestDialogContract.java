package com.example.blood_donationapp.ui.home;

import androidx.annotation.NonNull;

import com.example.blood_donationapp.base.BasePresenter;
import com.example.blood_donationapp.data.model.ReceiverDonorRequestType;
import com.example.blood_donationapp.ui.home.model.RequestDetails;

public interface RequestDialogContract {
  interface View {
    void getLastLocation();

    void dismissDialog(@NonNull String userId, boolean isReceiver, ReceiverDonorRequestType receiverDonorRequestType);
  }

  interface Presenter extends BasePresenter {

    void onSubmitButtonClick(RequestDetails requestDetails);

    void onLocationClick();
  }
}
