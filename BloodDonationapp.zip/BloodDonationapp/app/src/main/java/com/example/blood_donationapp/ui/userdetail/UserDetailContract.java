package com.example.blood_donationapp.ui.userdetail;

import com.example.blood_donationapp.base.BasePresenter;
import com.example.blood_donationapp.base.BaseView;
import com.example.blood_donationapp.ui.userdetail.model.UserDetail;


public interface UserDetailContract {
    interface Presenter extends BasePresenter {
        void onCreateNowClick(UserDetail userDetail);

        void onDobButtonClick();

        void onLocationClick();
    }

    interface View extends BaseView {
        void showDatePickerDialog();

        void getLastLocation();

        void launchHomeScreen();

    }
}
