package com.example.blood_donationapp.ui.home.model;

import android.databinding.ObservableDouble;
import com.example.blood_donationapp.common.binding.ObservableString;


public class RequestDetails {
  public ObservableString requestType = new ObservableString();
  public ObservableString bloodGroup = new ObservableString();
  public ObservableDouble latitude = new ObservableDouble();
  public ObservableDouble longitude = new ObservableDouble();
  public ObservableString purpose = new ObservableString();
}
